Thanks for downloading my cfg!

To install follow these steps:

1. Place the n2va.cfg file in [Drive where steam is installed]:\Program Files (x86)\Steam\steamapps\common\Counter-Strike Global Offensive\csgo\cfg
2. Either put +exec n2va.cfg in your CS:GO launch options or type exec n2va in the console when cs:go is open

Other info:
- video settings:
	- 4:3 stretched
	- all low settings
